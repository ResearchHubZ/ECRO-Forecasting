import argparse
import torch
from experiments.exp_long_term_forecasting import Exp_Long_Term_Forecast
from experiments.exp_long_term_forecasting_partial import Exp_Long_Term_Forecast_Partial
import random
import numpy as np
import os
import torch
torch.set_num_threads(4)

if __name__ == '__main__':
    fix_seed = 2021
    random.seed(fix_seed)
    torch.manual_seed(fix_seed)
    np.random.seed(fix_seed)
    torch.cuda.manual_seed(fix_seed)
    torch.cuda.manual_seed_all(fix_seed)  # if you are using multi-GPU.
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

    parser = argparse.ArgumentParser(description='iTransformer')

    # basic config
    parser.add_argument('--task_name', type=str, default='long_term_forecast')
    parser.add_argument('--is_training', type=int, default=0, help='status')
    parser.add_argument('--model_id', type=str, default='test', help='model id')
    parser.add_argument('--model', type=str, default='multi_iTran',
                        help='model name, options: [iTransformer, iInformer, iReformer, iFlowformer, iFlashformer]')

    # data loader
    parser.add_argument('--data', type=str, default='custom', help='dataset type')
    parser.add_argument('--root_path', type=str, default='./data/', help='root path of the data file')
    parser.add_argument('--data_path', type=str, default='Economy_text.csv', help='data csv file')
    parser.add_argument('--main_model', type=str, default='iTransformer') #TimeXer/WPMixer需要patch_len
    # parser.add_argument('--llm_model', type=str, default='LLAMA') 
    # parser.add_argument('--llm_path', type=str, default='/home/admin123/zhanying/T3Time-news/T3Time-main-1/pre-model/Llama-2-7b-chat-hf') #
    parser.add_argument('--features', type=str, default='S',
                        help='forecasting task, options:[M, S, MS]; M:multivariate predict multivariate, S:univariate predict univariate, MS:multivariate predict univariate')
    parser.add_argument('--target', type=str, default='OT', help='target feature in S or MS task')
    parser.add_argument('--freq', type=str, default='m',
                        help='freq for time features encoding, options:[s:secondly, t:minutely, h:hourly, d:daily, b:business days, w:weekly, m:monthly], you can also use more detailed freq like 15min or 3h')
    parser.add_argument('--checkpoints', type=str, default='./checkpoints/', help='location of model checkpoints')

    # forecasting task
    parser.add_argument('--seq_len', type=int, default=24, help='input sequence length')   #512
    parser.add_argument('--label_len', type=int, default=0, help='start token length') #no longer needed in inverted Transformers
    parser.add_argument('--pred_len', type=int, default=12, help='prediction sequence length')

    # model define
    parser.add_argument('--enc_in', type=int, default=1, help='encoder input size')
    parser.add_argument('--dec_in', type=int, default=1, help='decoder input size')
    parser.add_argument('--c_out', type=int, default=1, help='output size') # applicable on arbitrary number of variates in inverted Transformers
    parser.add_argument('--d_model', type=int, default=512, help='dimension of model')
    parser.add_argument('--n_heads', type=int, default=8, help='num of heads')
    parser.add_argument('--e_layers', type=int, default=2, help='num of encoder layers')    #2
    parser.add_argument('--d_layers', type=int, default=1, help='num of decoder layers')
    parser.add_argument('--d_ff', type=int, default=2048, help='dimension of fcn')
    parser.add_argument('--moving_avg', type=int, default=25, help='window size of moving average')
    parser.add_argument('--factor', type=int, default=1, help='attn factor')
    parser.add_argument('--distil', action='store_false',
                        help='whether to use distilling in encoder, using this argument means not using distilling',
                        default=True)
    parser.add_argument('--dropout', type=float, default=0.1, help='dropout')
    parser.add_argument('--embed', type=str, default='timeF',
                        help='time features encoding, options:[timeF, fixed, learned]')
    parser.add_argument('--activation', type=str, default='gelu', help='activation')
    parser.add_argument('--output_attention', action='store_true', help='whether to output attention in ecoder')
    parser.add_argument('--do_predict', action='store_true', default=False, help='whether to predict unseen future data')

    # optimization
    parser.add_argument('--num_workers', type=int, default=50, help='data loader num workers')
    parser.add_argument('--itr', type=int, default=1, help='experiments times')
    parser.add_argument('--train_epochs', type=int, default=10, help='train epochs')
    parser.add_argument('--batch_size', type=int, default=32, help='batch size of train input data')
    parser.add_argument('--patience', type=int, default=3, help='early stopping patience')
    parser.add_argument('--learning_rate', type=float, default=0.0001, help='optimizer learning rate')
    parser.add_argument('--des', type=str, default='test', help='exp description')
    parser.add_argument('--loss', type=str, default='MSE', help='loss function')
    parser.add_argument('--lradj', type=str, default='type1', help='adjust learning rate')
    parser.add_argument('--use_amp', action='store_true', help='use automatic mixed precision training', default=False)

    # GPU
    parser.add_argument('--use_gpu', type=bool, default=True, help='use gpu')
    parser.add_argument('--gpu', type=int, default=0, help='gpu')
    parser.add_argument('--use_multi_gpu', action='store_true', help='use multiple gpus', default=True)
    parser.add_argument('--devices', type=str, default='3,5,6', help='device ids of multile gpus')

    # iTransformer
    parser.add_argument('--exp_name', type=str, required=False, default='MTSF',
                        help='experiemnt name, options:[MTSF, partial_train]')
    parser.add_argument('--channel_independence', type=bool, default=False, help='whether to use channel_independence mechanism')
    parser.add_argument('--inverse', action='store_true', help='inverse output data', default=False)
    parser.add_argument('--class_strategy', type=str, default='projection', help='projection/average/cls_token')
    # parser.add_argument('--target_root_path', type=str, default='./data/electricity/', help='root path of the data file')
    # parser.add_argument('--target_data_path', type=str, default='electricity.csv', help='data file')
    parser.add_argument('--efficient_training', type=bool, default=False, help='whether to use efficient_training (exp_name should be partial train)') # See Figure 8 of our paper for the detail
    parser.add_argument('--use_norm', type=int, default=True, help='use norm and denorm')
    parser.add_argument('--partial_start_index', type=int, default=0, help='the start index of variates for partial training, '
                                                                           'you can select [partial_start_index, min(enc_in + partial_start_index, N)]')

    # parser.add_argument('--pool_type', type=str, default='avg', help='pooling type') #avg min max attention
    parser.add_argument('--patch_len', type=int, default=16)    #6
    # parser.add_argument('--token_len', type=int, default=8)
    parser.add_argument('--n_vars', type=int, default=1) 
    parser.add_argument('--num_distill', type=int, default=16)  #文本蒸馏后的token,9, 16
    parser.add_argument('--num_text_cross_layers', type=int, default=1) 
    parser.add_argument('--num_text_connect_layers', type=int, default=1)
    parser.add_argument('--intermediate_size', type=int, default=1024)
    # parser.add_argument('--num_prototypes', type=int, default=1000)   #1000
    # # parser.add_argument('--token_len', type=int, default=6)
    # parser.add_argument('--num_retriever_enc_layers', type=int, default=1)
    # parser.add_argument('--num_retriever_dec_layers', type=int, default=1)
    # parser.add_argument('--diffusion_batch_mul', type=int, default=4)   #4
    # parser.add_argument('--flow_loss_depth', type=int, default=3)   #3
    # parser.add_argument('--num_sampling_steps', type=int, default=50)   #这个改结果变化不大, 50
    # parser.add_argument('--num_samples', type=int, default=100)  #100
    parser.add_argument('--norm_mode', type=str, default='batch')  
    parser.add_argument('--hidden_act', type=str, default='silu')
    parser.add_argument('--output_dir', type=str, default=None)
    parser.add_argument('--num_basis', type=int, default=24)  #6,44

    # DeformTime parameters
    parser.add_argument('--kernel', type=int, default=6, help='kernel size')
    parser.add_argument('--n_reshape', type=int, default=16)
    parser.add_argument('--top_k', type=int, default=5, help='for TimesBlock')
    parser.add_argument('--num_kernels', type=int, default=6, help='for Inception')

    # Text preprocessing optimization
    parser.add_argument('--use_preprocessed_tokens', type=bool, default=True, 
                        help='whether to use preprocessed text tokens (faster training)')

    args = parser.parse_args()
    # args.token_len = args.pred_len
    args.stride = args.patch_len
    
    args.use_gpu = True if torch.cuda.is_available() and args.use_gpu else False

    # 设置GPU设备
    if args.use_gpu:
        # 如果使用多卡模式，根据devices参数设置可见GPU
        if args.use_multi_gpu:
            args.devices = args.devices.replace(' ', '')
            device_ids = args.devices.split(',')
            original_device_ids = [int(id_) for id_ in device_ids]
            # 设置CUDA_VISIBLE_DEVICES为指定的GPU列表
            os.environ['CUDA_VISIBLE_DEVICES'] = args.devices
            # 设置device_ids为相对索引 [0, 1, 2, ...]，因为CUDA_VISIBLE_DEVICES会重新映射GPU
            args.device_ids = list(range(len(original_device_ids)))
            args.gpu = args.device_ids[0]
            print(f"[Multi-GPU Mode] Original GPUs: {original_device_ids}, Mapped to: {args.device_ids}")
        else:
            # 单卡模式，使用指定的gpu编号
            os.environ['CUDA_VISIBLE_DEVICES'] = str(args.gpu)
            args.device_ids = [args.gpu]
            print(f"[Single-GPU Mode] Using GPU: {args.gpu}")

    print('Args in experiment:')
    print(args)

    if args.exp_name == 'partial_train': # See Figure 8 of our paper, for the detail
        Exp = Exp_Long_Term_Forecast_Partial
    else: # MTSF: multivariate time series forecasting
        Exp = Exp_Long_Term_Forecast


    if args.is_training:
        for ii in range(args.itr):
            # setting record of experiments
            setting = '{}_{}_{}_{}_ft{}_sl{}_ll{}_pl{}_dm{}_nh{}_el{}_dl{}_df{}_fc{}_eb{}_dt{}_{}_{}'.format(
                args.model_id,
                args.model,
                args.data,
                args.features,
                args.seq_len,
                args.label_len,
                args.pred_len,
                args.d_model,
                args.n_heads,
                args.e_layers,
                args.d_layers,
                args.d_ff,
                args.factor,
                args.embed,
                args.distil,
                args.des,
                args.class_strategy, ii)

            exp = Exp(args)  # set experiments
            print('>>>>>>>start training : {}>>>>>>>>>>>>>>>>>>>>>>>>>>'.format(setting))
            exp.train(setting)

            print('>>>>>>>testing : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'.format(setting))
            exp.test(setting)

            if args.do_predict:
                print('>>>>>>>predicting : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'.format(setting))
                exp.predict(setting, False)

            torch.cuda.empty_cache()
    else:
        ii = 0
        setting = '{}_{}_{}_{}_ft{}_sl{}_ll{}_pl{}_dm{}_nh{}_el{}_dl{}_df{}_fc{}_eb{}_dt{}_{}_{}'.format(
            args.model_id,
            args.model,
            args.data,
            args.features,
            args.seq_len,
            args.label_len,
            args.pred_len,
            args.d_model,
            args.n_heads,
            args.e_layers,
            args.d_layers,
            args.d_ff,
            args.factor,
            args.embed,
            args.distil,
            args.des,
            args.class_strategy, ii)

        exp = Exp(args)  # set experiments
        print('>>>>>>>testing : {}<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'.format(setting))
        exp.test(setting, test=1)
        torch.cuda.empty_cache()
