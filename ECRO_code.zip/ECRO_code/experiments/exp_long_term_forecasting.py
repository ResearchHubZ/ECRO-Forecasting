from data_provider.data_factory import data_provider
from experiments.exp_basic import Exp_Basic
from utils.tools import EarlyStopping, adjust_learning_rate, visual
from utils.metrics import metric

import torch
import torch.nn as nn
from torch import optim

import os
import time
import warnings
import numpy as np

from transformers import (
    LlamaConfig,
    LlamaModel,
    LlamaTokenizer,
    GPT2Config,
    GPT2Model,
    GPT2Tokenizer
)

warnings.filterwarnings('ignore')


class Exp_Long_Term_Forecast(Exp_Basic):
    def __init__(self, args):
        super(Exp_Long_Term_Forecast, self).__init__(args)

    def _build_model(self):
        model = self.model_dict[self.args.model].Model(self.args).float()

        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)

        return model

    def _get_data(self, flag):
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _select_optimizer(self):
        model_optim = optim.Adam(
            self.model.parameters(),
            lr=self.args.learning_rate
        )
        return model_optim

    def _select_criterion(self):
        criterion = nn.MSELoss()
        return criterion

    def vali(self, vali_data, vali_loader, criterion):
        total_loss = []
        self.model.eval()

        with torch.no_grad():
            for i, (
                batch_x,
                batch_y,
                batch_x_mark,
                batch_y_mark,
                batch_input_ids,
                batch_attention_mask,
                batch_token_type_ids
            ) in enumerate(vali_loader):

                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                batch_input_ids = batch_input_ids.to(self.device)
                batch_attention_mask = batch_attention_mask.to(self.device)
                batch_token_type_ids = batch_token_type_ids.to(self.device)

                if 'PEMS' in self.args.data or 'Solar' in self.args.data:
                    batch_x_mark = None
                    batch_y_mark = None
                else:
                    batch_x_mark = batch_x_mark.float().to(self.device)
                    batch_y_mark = batch_y_mark.float().to(self.device)

                dec_inp = torch.zeros_like(
                    batch_y[:, -self.args.pred_len:, :]
                ).float()

                dec_inp = torch.cat(
                    [batch_y[:, :self.args.label_len, :], dec_inp],
                    dim=1
                ).float().to(self.device)

                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            output = self.model(
                                batch_x,
                                batch_x_mark,
                                dec_inp,
                                batch_y_mark
                            )[0]
                            outputs = output
                        else:
                            output = self.model(
                                batch_x,
                                batch_x_mark,
                                dec_inp,
                                batch_y_mark,
                                batch_input_ids,
                                batch_attention_mask,
                                batch_token_type_ids,
                                None
                            )
                            outputs = output.logits
                else:
                    if self.args.output_attention:
                        output = self.model(
                            batch_x,
                            batch_x_mark,
                            dec_inp,
                            batch_y_mark
                        )[0]
                        outputs = output
                    else:
                        output = self.model(
                            batch_x,
                            batch_x_mark,
                            dec_inp,
                            batch_y_mark,
                            batch_input_ids,
                            batch_attention_mask,
                            batch_token_type_ids,
                            None
                        )
                        outputs = output.logits

                outputs = outputs[:, -self.args.pred_len:, :]
                batch_y = batch_y[:, -self.args.pred_len:, :].to(self.device)

                pred = outputs.detach().cpu()
                true = batch_y.detach().cpu()

                loss = criterion(pred, true)
                total_loss.append(loss.item())

        total_loss = np.average(total_loss)
        self.model.train()

        return total_loss

    def train(self, setting):
        train_data, train_loader = self._get_data(flag='train')
        vali_data, vali_loader = self._get_data(flag='val')
        test_data, test_loader = self._get_data(flag='test')

        path = os.path.join(self.args.checkpoints, setting)
        if not os.path.exists(path):
            os.makedirs(path)

        time_now = time.time()

        train_steps = len(train_loader)
        early_stopping = EarlyStopping(
            patience=self.args.patience,
            verbose=True
        )

        model_optim = self._select_optimizer()
        criterion = self._select_criterion()

        if self.args.use_amp:
            scaler = torch.cuda.amp.GradScaler()

        for epoch in range(self.args.train_epochs):
            iter_count = 0
            train_loss = []

            self.model.train()
            epoch_time = time.time()

            for i, (
                batch_x,
                batch_y,
                batch_x_mark,
                batch_y_mark,
                batch_input_ids,
                batch_attention_mask,
                batch_token_type_ids
            ) in enumerate(train_loader):

                iter_count += 1
                model_optim.zero_grad()

                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                batch_input_ids = batch_input_ids.to(self.device)
                batch_attention_mask = batch_attention_mask.to(self.device)
                batch_token_type_ids = batch_token_type_ids.to(self.device)

                if 'PEMS' in self.args.data or 'Solar' in self.args.data:
                    batch_x_mark = None
                    batch_y_mark = None
                else:
                    batch_x_mark = batch_x_mark.float().to(self.device)
                    batch_y_mark = batch_y_mark.float().to(self.device)

                dec_inp = torch.zeros_like(
                    batch_y[:, -self.args.pred_len:, :]
                ).float()

                dec_inp = torch.cat(
                    [batch_y[:, :self.args.label_len, :], dec_inp],
                    dim=1
                ).float().to(self.device)

                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        if self.args.output_attention:
                            outputs = self.model(
                                batch_x,
                                batch_x_mark,
                                dec_inp,
                                batch_y_mark
                            )[0]

                            f_dim = -1 if self.args.features == 'MS' else 0
                            outputs = outputs[:, -self.args.pred_len:, f_dim:]
                            batch_y_loss = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)

                            loss = criterion(outputs, batch_y_loss)

                        else:
                            output_obj = self.model(
                                batch_x,
                                batch_x_mark,
                                dec_inp,
                                batch_y_mark,
                                batch_input_ids,
                                batch_attention_mask,
                                batch_token_type_ids,
                                batch_y
                            )

                            loss = output_obj.loss

                            if loss.dim() > 0:
                                loss = loss.mean()

                    train_loss.append(loss.item())

                else:
                    if self.args.output_attention:
                        outputs = self.model(
                            batch_x,
                            batch_x_mark,
                            dec_inp,
                            batch_y_mark
                        )[0]

                        f_dim = -1 if self.args.features == 'MS' else 0
                        outputs = outputs[:, -self.args.pred_len:, f_dim:]
                        batch_y_loss = batch_y[:, -self.args.pred_len:, f_dim:].to(self.device)

                        loss = criterion(outputs, batch_y_loss)

                    else:
                        output_obj = self.model(
                            batch_x,
                            batch_x_mark,
                            dec_inp,
                            batch_y_mark,
                            batch_input_ids,
                            batch_attention_mask,
                            batch_token_type_ids,
                            batch_y
                        )

                        loss = output_obj.loss

                        if loss.dim() > 0:
                            loss = loss.mean()

                    train_loss.append(loss.item())

                if (i + 1) % 100 == 0:
                    print(
                        "\titers: {0}, epoch: {1} | loss: {2:.7f}".format(
                            i + 1,
                            epoch + 1,
                            loss.item()
                        )
                    )

                    speed = (time.time() - time_now) / iter_count
                    left_time = speed * (
                        (self.args.train_epochs - epoch) * train_steps - i
                    )

                    print(
                        '\tspeed: {:.4f}s/iter; left time: {:.4f}s'.format(
                            speed,
                            left_time
                        )
                    )

                    iter_count = 0
                    time_now = time.time()

                if self.args.use_amp:
                    scaler.scale(loss).backward()
                    scaler.step(model_optim)
                    scaler.update()
                else:
                    loss.backward()
                    model_optim.step()

            print(
                "Epoch: {} cost time: {}".format(
                    epoch + 1,
                    time.time() - epoch_time
                )
            )

            train_loss = np.average(train_loss)
            vali_loss = self.vali(vali_data, vali_loader, criterion)

            print(
                "Epoch: {0}, Steps: {1} | Train Loss: {2:.7f} Vali Loss: {3:.7f}".format(
                    epoch + 1,
                    train_steps,
                    train_loss,
                    vali_loss
                )
            )

            early_stopping(vali_loss, self.model, path)

            if early_stopping.early_stop:
                print("Early stopping")
                break

            adjust_learning_rate(model_optim, epoch + 1, self.args)

        best_model_path = path + '/' + 'checkpoint.pth'
        best_model = torch.load(best_model_path, map_location='cpu')
        self.model.load_state_dict(best_model)
        self.model.to(self.device)

        return self.model

    def test(self, setting, test=0):

        import os
        import numpy as np
        import pandas as pd
        import torch

        test_data, test_loader = self._get_data(flag='test')

        if test:
            print('loading model')
            self.model.load_state_dict(
                torch.load(
                    os.path.join('./checkpoints/' + setting, 'checkpoint.pth'),
                    map_location=self.device
                )
            )

        folder_path = './results/' + setting + '/'
        os.makedirs(folder_path, exist_ok=True)

        folder_path1 = './results_定量/'
        os.makedirs(folder_path1, exist_ok=True)

        all_sample_result_dir = os.path.join(
            folder_path1,
            f"test_all_samples_total_response_pred{self.args.pred_len}"
        )
        os.makedirs(all_sample_result_dir, exist_ok=True)

        all_sample_npy_dir = os.path.join(
            folder_path,
            f"test_all_samples_total_response_pred{self.args.pred_len}"
        )
        os.makedirs(all_sample_npy_dir, exist_ok=True)

        self.model.eval()

        if len(test_data) == 0:
            print("❌ test_data 为空")
            return

        if isinstance(self.model, torch.nn.DataParallel):
            forward_model = self.model.module
            forward_model.eval()
            print("⚠️ DataParallel detected. Use self.model.module for explainable test forward.")
        else:
            forward_model = self.model
            forward_model.eval()

        # ======================================================
        # 统一整理为 [B, pred_len, 1]
        # ======================================================
        def to_target_shape(arr):
            arr = np.asarray(arr)

            if arr.ndim == 3:
                if arr.shape[1] == 1 and arr.shape[2] == self.args.pred_len:
                    arr = arr.transpose(0, 2, 1)

                if arr.shape[-1] > 1:
                    arr = arr[:, :, -1:]

                return arr

            elif arr.ndim == 2:
                return arr[:, :, None]

            else:
                raise ValueError(f"Unsupported arr shape: {arr.shape}")

        # ======================================================
        # 获取 scaler 信息
        # 默认目标列为最后一列
        # 如果你的目标列不是最后一列，可以在 args 里额外加 target_col_idx
        # ======================================================
        def get_scaler_info(scaler):
            if hasattr(scaler, "mean_"):
                n_features = len(scaler.mean_)
            elif hasattr(scaler, "data_min_"):
                n_features = len(scaler.data_min_)
            elif hasattr(scaler, "n_features_in_"):
                n_features = int(scaler.n_features_in_)
            else:
                n_features = 1

            target_col_idx = getattr(self.args, "target_col_idx", None)

            if target_col_idx is None:
                target_col_idx = n_features - 1

            if target_col_idx < 0:
                target_col_idx = n_features + target_col_idx

            if target_col_idx < 0 or target_col_idx >= n_features:
                raise ValueError(
                    f"Invalid target_col_idx={target_col_idx}, "
                    f"but scaler has n_features={n_features}"
                )

            return n_features, target_col_idx

        # ======================================================
        # 目标变量反归一化
        # 输出统一为 [B, pred_len, 1]
        # ======================================================
        def inverse_target(arr):
            arr = np.asarray(arr)

            if arr.ndim == 3:
                if arr.shape[1] == 1 and arr.shape[2] == self.args.pred_len:
                    arr = arr.transpose(0, 2, 1)

                B, T, C = arr.shape

            elif arr.ndim == 2:
                B, T = arr.shape
                C = 1
                arr = arr[:, :, None]

            else:
                raise ValueError(
                    f"Unsupported arr shape for inverse: {arr.shape}"
                )

            scaler = test_data.scaler
            n_features, target_col_idx = get_scaler_info(scaler)

            # 单变量 scaler
            if n_features == 1:
                arr_2d = arr.reshape(-1, 1)
                inv_2d = scaler.inverse_transform(arr_2d)
                return inv_2d.reshape(B, T, 1)

            # arr 本身是完整多变量
            if C == n_features:
                arr_2d = arr.reshape(-1, C)
                inv_2d = scaler.inverse_transform(arr_2d)
                inv_target = inv_2d[:, target_col_idx:target_col_idx + 1]
                return inv_target.reshape(B, T, 1)

            # arr 只有目标变量一列
            arr_target = arr[:, :, 0].reshape(-1)

            arr_expand = np.zeros(
                (B * T, n_features),
                dtype=arr.dtype
            )

            arr_expand[:, target_col_idx] = arr_target

            inv_expand = scaler.inverse_transform(arr_expand)
            inv_target = inv_expand[:, target_col_idx:target_col_idx + 1]

            return inv_target.reshape(B, T, 1)

        # ======================================================
        # 保存 CSV 时强制反归一化到真实量纲
        # 不再依赖 self.args.inverse
        # ======================================================
        use_inverse = (
            hasattr(test_data, "scale")
            and test_data.scale
            and hasattr(test_data, "scaler")
        )

        print(f"✅ use_inverse for saving real values: {use_inverse}")

        if use_inverse:
            n_features, target_col_idx = get_scaler_info(test_data.scaler)
            print(
                f"✅ scaler n_features={n_features}, "
                f"target_col_idx={target_col_idx}"
            )
        else:
            print("⚠️ 当前 test_data 未启用 scaler，保存结果将保持模型输出尺度。")

        preds_all = []
        trues_all = []
        metrics_records = []

        global_sample_idx = 0

        with torch.no_grad():

            for i, (
                batch_x,
                batch_y,
                batch_x_mark,
                batch_y_mark,
                batch_input_ids,
                batch_attention_mask,
                batch_token_type_ids
            ) in enumerate(test_loader):

                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                batch_input_ids = batch_input_ids.to(self.device)
                batch_attention_mask = batch_attention_mask.to(self.device)
                batch_token_type_ids = batch_token_type_ids.to(self.device)

                if 'PEMS' in self.args.data or 'Solar' in self.args.data:
                    batch_x_mark = None
                    batch_y_mark = None
                else:
                    batch_x_mark = batch_x_mark.float().to(self.device)
                    batch_y_mark = batch_y_mark.float().to(self.device)

                dec_inp = torch.zeros_like(
                    batch_y[:, -self.args.pred_len:, :]
                ).float()

                dec_inp = torch.cat(
                    [batch_y[:, :self.args.label_len, :], dec_inp],
                    dim=1
                ).float().to(self.device)

                if self.args.use_amp:
                    with torch.cuda.amp.autocast():
                        output = forward_model(
                            batch_x,
                            batch_x_mark,
                            dec_inp,
                            batch_y_mark,
                            batch_input_ids,
                            batch_attention_mask,
                            batch_token_type_ids,
                            None,
                            return_explain=True
                        )
                else:
                    output = forward_model(
                        batch_x,
                        batch_x_mark,
                        dec_inp,
                        batch_y_mark,
                        batch_input_ids,
                        batch_attention_mask,
                        batch_token_type_ids,
                        None,
                        return_explain=True
                    )

                # ======================================================
                # 归一化空间结果
                # ======================================================
                final_pred_norm = output["logits"][:, -self.args.pred_len:, :]   # [B, pred_len, 1]
                base_pred_norm = output["base_pred"]                            # [B, 1, pred_len]
                residual_norm = output["residual"]                              # [B, pred_len]
                true_norm = batch_y[:, -self.args.pred_len:, :]                  # [B, pred_len, C]

                final_pred_norm_np = final_pred_norm.detach().cpu().numpy()
                base_pred_norm_np = base_pred_norm.detach().cpu().numpy()
                residual_norm_np = residual_norm.detach().cpu().numpy()
                true_norm_np = true_norm.detach().cpu().numpy()

                final_pred_norm_target = to_target_shape(final_pred_norm_np)
                base_pred_norm_target = to_target_shape(base_pred_norm_np)
                residual_norm_target = to_target_shape(residual_norm_np)
                true_norm_target = to_target_shape(true_norm_np)

                # ======================================================
                # 反归一化
                # true / base / final 进入真实用电量量纲
                # residual 不直接反归一化，而是用真实量纲差值计算
                # ======================================================
                if use_inverse:
                    final_pred_real = inverse_target(final_pred_norm_target)
                    base_pred_real = inverse_target(base_pred_norm_target)
                    true_real = inverse_target(true_norm_np)
                else:
                    final_pred_real = final_pred_norm_target
                    base_pred_real = base_pred_norm_target
                    true_real = true_norm_target

                total_residual_real = final_pred_real - base_pred_real

                true_min = float(np.nanmin(true_real))
                true_max = float(np.nanmax(true_real))

                if true_min < 0:
                    print(
                        f"⚠️ Warning: true_real still has negative values. "
                        f"min={true_min}, max={true_max}. "
                        f"请检查 target_col_idx 或 scaler 列顺序。"
                    )

                preds_all.append(final_pred_real)
                trues_all.append(true_real)

                B = final_pred_real.shape[0]

                for b in range(B):

                    global_sample_idx += 1
                    sample_prefix = f"sample_{global_sample_idx:05d}"

                    sample_true = true_real[b, :, 0]
                    sample_base = base_pred_real[b, :, 0]
                    sample_final = final_pred_real[b, :, 0]
                    sample_residual = total_residual_real[b, :, 0]

                    sample_true_norm = true_norm_target[b, :, 0]
                    sample_base_norm = base_pred_norm_target[b, :, 0]
                    sample_final_norm = final_pred_norm_target[b, :, 0]
                    sample_residual_norm = residual_norm_target[b, :, 0]

                    mae_s, mse_s, rmse_s, mape_s, mspe_s = metric(
                        final_pred_real[b:b + 1],
                        true_real[b:b + 1]
                    )

                    metrics_records.append({
                        "sample_id": global_sample_idx - 1,
                        "sample_name": sample_prefix,
                        "mae": float(mae_s),
                        "mse": float(mse_s),
                        "rmse": float(rmse_s),
                        "mape": float(mape_s),
                        "mspe": float(mspe_s)
                    })

                    records = []

                    for h in range(self.args.pred_len):
                        records.append({
                            "sample_id": global_sample_idx - 1,
                            "sample_name": sample_prefix,
                            "step": h + 1,

                            # 真实用电量量纲
                            "true": float(sample_true[h]),
                            "base_pred": float(sample_base[h]),
                            "final_pred": float(sample_final[h]),
                            "total_residual": float(sample_residual[h]),

                            # 归一化空间，仅用于调试
                            "true_norm": float(sample_true_norm[h]),
                            "base_pred_norm": float(sample_base_norm[h]),
                            "final_pred_norm": float(sample_final_norm[h]),
                            "total_residual_norm": float(sample_residual_norm[h]),

                            "mae": float(mae_s),
                            "mse": float(mse_s),
                            "rmse": float(rmse_s),
                            "mape": float(mape_s),
                            "mspe": float(mspe_s)
                        })

                    sample_df = pd.DataFrame(records)

                    sample_csv_path = os.path.join(
                        all_sample_result_dir,
                        f"{sample_prefix}_total_response_pred{self.args.pred_len}.csv"
                    )

                    sample_df.to_csv(
                        sample_csv_path,
                        index=False,
                        encoding="utf-8-sig"
                    )

                    np.save(
                        os.path.join(
                            all_sample_npy_dir,
                            sample_prefix + "_true_real.npy"
                        ),
                        sample_true
                    )

                    np.save(
                        os.path.join(
                            all_sample_npy_dir,
                            sample_prefix + "_base_pred_real.npy"
                        ),
                        sample_base
                    )

                    np.save(
                        os.path.join(
                            all_sample_npy_dir,
                            sample_prefix + "_final_pred_real.npy"
                        ),
                        sample_final
                    )

                    np.save(
                        os.path.join(
                            all_sample_npy_dir,
                            sample_prefix + "_total_residual_real.npy"
                        ),
                        sample_residual
                    )

                    print(
                        f"✅ 保存样本 {sample_prefix}: "
                        f"mse={mse_s}, mae={mae_s}, csv={sample_csv_path}"
                    )

        preds = np.concatenate(preds_all, axis=0)
        trues = np.concatenate(trues_all, axis=0)

        print('test shape:', preds.shape, trues.shape)

        mae, mse, rmse, mape, mspe = metric(preds, trues)

        print('mse:{}, mae:{}'.format(mse, mae))

        with open("result_long_term_forecast.txt", 'a') as f:
            f.write(setting + "  \n")
            f.write('mse:{}, mae:{}'.format(mse, mae))
            f.write('\n\n')

        np.save(
            folder_path + 'metrics.npy',
            np.array([mae, mse, rmse, mape, mspe])
        )

        np.save(folder_path + 'pred.npy', preds)
        np.save(folder_path + 'true.npy', trues)

        metrics_df = pd.DataFrame(metrics_records)

        metrics_csv_path = os.path.join(
            all_sample_result_dir,
            f"all_samples_metrics_pred{self.args.pred_len}.csv"
        )

        metrics_df.to_csv(
            metrics_csv_path,
            index=False,
            encoding="utf-8-sig"
        )

        print(f"✅ 所有样本总残差响应 CSV 已保存到: {all_sample_result_dir}")
        print(f"✅ 每个样本指标已保存到: {metrics_csv_path}")

        return

    