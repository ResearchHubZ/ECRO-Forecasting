import torch.nn as nn 
import torch
import math
import torch.nn.functional as F
from transformers.activations import ACT2FN
from typing import Optional

def sinusoidal_position_embedding(
        batch_size: int,
        num_heads: int,
        max_len: int,
        output_dim: int,
        device: torch.device,
        factor: float = 1.0
) -> torch.Tensor:
    """
    Generate sinusoidal position embeddings.

    Args:
        batch_size (int): Batch size.
        num_heads (int): Number of attention heads.
        max_len (int): Maximum sequence length.
        output_dim (int): Output dimension.
        device (torch.device): Device type.
        factor (float, optional): Scaling factor. Defaults to 1.0.

    Returns:
        torch.Tensor: Sinusoidal position embedding tensor with shape (bs, head, max_len, output_dim).
    """
    # Generate position indices
    position = torch.arange(0, max_len * factor, 1 / factor, dtype=torch.float).unsqueeze(-1)
    # Generate frequency indices
    ids = torch.arange(0, output_dim // 2, dtype=torch.float)
    theta = torch.pow(10000, -2 * ids / output_dim)

    # Calculate position embeddings
    embeddings = position * theta
    embeddings = torch.stack([torch.sin(embeddings), torch.cos(embeddings)], dim=-1)

    # Expand dimensions to match batch size and number of attention heads
    embeddings = embeddings.repeat((batch_size, num_heads, *([1] * len(embeddings.shape))))
    embeddings = torch.reshape(embeddings, (batch_size, num_heads, -1, output_dim))
    embeddings = embeddings.to(device)

    # If the factor is greater than 1, perform interpolation
    if factor > 1.0:
        interpolation_indices = torch.linspace(0, embeddings.shape[2] - 1, max_len).long()
        embeddings = embeddings[:, :, interpolation_indices, :]

    return embeddings

def RoPE_decoder(query: torch.Tensor, key: torch.Tensor):
    """
    Apply Rotary Position Embedding (RoPE) to the query and key tensors in the decoder.

    Args:
        query (torch.Tensor): Query tensor with shape (bs, head, q_max_len, output_dim).
        key (torch.Tensor): Key tensor with shape (bs, head, k_max_len, output_dim).

    Returns:
        Tuple[torch.Tensor, torch.Tensor]: Query and key tensors after applying RoPE.
    """
    # Get the shape information of the input tensors
    batch_size, num_heads, q_max_len, output_dim = query.shape
    _, _, k_max_len, _ = key.shape
    # Generate sinusoidal position embeddings
    pos_emb = sinusoidal_position_embedding(batch_size, num_heads, k_max_len + q_max_len, output_dim, query.device,
                                            factor=1)

    # Extract cosine and sine position embeddings
    cos_pos = pos_emb[..., 1::2].repeat_interleave(2, dim=-1)
    sin_pos = pos_emb[..., ::2].repeat_interleave(2, dim=-1)

    # Apply RoPE to the query tensor
    query_rot = torch.stack([-query[..., 1::2], query[..., ::2]], dim=-1).reshape(query.shape)
    query = query * cos_pos[:, :, -q_max_len:, :] + query_rot * sin_pos[:, :, -q_max_len:, :]

    # Apply RoPE to the key tensor
    key_rot = torch.stack([-key[..., 1::2], key[..., ::2]], dim=-1).reshape(key.shape)
    key = key * cos_pos[:, :, :k_max_len, :] + key_rot * sin_pos[:, :, :k_max_len, :]

    return query, key

class Attention(nn.Module):
    def __init__(self, config, rope: bool = False):
        super().__init__()
        self.hidden_size = config.d_model
        self.num_heads = config.n_heads
        self.head_dim = self.hidden_size // self.num_heads
        self.attention_dropout = config.dropout
        self.q_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=True)
        self.k_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=True)
        self.v_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=True)
        self.o_proj = nn.Linear(self.hidden_size, self.hidden_size, bias=False)
        self.rope = rope

    def _scaled_dot_product_attention(self, Q, K, V, bias=None, attn_mask=None):
        attn_scores = torch.matmul(Q, K.transpose(-2, -1))
        attn_scores = attn_scores / math.sqrt(Q.size(-1))

        if attn_mask is not None:
            if attn_mask.dtype == torch.bool:
                attn_scores = attn_scores.masked_fill(attn_mask, float('-inf'))
            else:
                attn_scores = attn_scores + attn_mask

        if bias is not None:
            if attn_scores.shape[0] > bias.shape[0]:
                bias = bias.repeat(attn_scores.shape[0] // bias.shape[0], 1, 1, 1)
            attn_scores += bias

        attn_weights = F.softmax(attn_scores, dim=-1)

        if self.attention_dropout > 0.0 and self.training:
            attn_weights = F.dropout(attn_weights, p=self.attention_dropout)

        attn_output = torch.matmul(attn_weights, V)

        return attn_output, attn_scores

    def forward(
            self,
            hidden_states: torch.Tensor,
            key_embedding: torch.Tensor = None,
            value_embedding: torch.Tensor = None,
            attention_mask: Optional[torch.Tensor] = None,
            output_attentions: bool = False,
            bias: torch.Tensor = None,
            **kwargs,
    ):
        bsz, q_len, _ = hidden_states.size()

        if key_embedding is None:
            key_embedding = hidden_states
        if value_embedding is None:
            value_embedding = hidden_states

        _, k_len, _ = key_embedding.size()
        _, v_len, _ = value_embedding.size()

        query_states = self.q_proj(hidden_states)
        key_states = self.k_proj(key_embedding)
        value_states = self.v_proj(value_embedding)

        query_states = query_states.view(
            bsz, q_len, self.num_heads, self.head_dim).transpose(1, 2)
        key_states = key_states.view(
            bsz, k_len, self.num_heads, self.head_dim).transpose(1, 2)
        value_states = value_states.view(
            bsz, v_len, self.num_heads, self.head_dim).transpose(1, 2)

        if self.rope:
            query_states, key_states = RoPE_decoder(query_states, key_states)

        attn_output, attn_scores = self._scaled_dot_product_attention(
            Q=query_states, K=key_states, V=value_states, bias=bias,
            attn_mask=attention_mask)

        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.reshape(bsz, q_len, self.hidden_size)
        attn_output = self.o_proj(attn_output)

        if not output_attentions:
            attn_scores = None

        return attn_output, attn_scores

class FFN(nn.Module):
    def __init__(self, hidden_size: int, intermediate_size: int, hidden_act: str):
        super().__init__()
        self.ffn = nn.Sequential(nn.Linear(hidden_size, intermediate_size),
                                 ACT2FN[hidden_act],
                                 nn.Linear(intermediate_size, hidden_size))

    def forward(self, hidden_state):
        return self.ffn(hidden_state)