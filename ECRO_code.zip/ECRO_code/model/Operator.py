import torch
import torch.nn as nn
import torch.nn.functional as F

class TextTrunk(nn.Module):
    def __init__(self, configs):
        super().__init__()
        self.num_basis = configs.num_basis
        self.pred_len = configs.pred_len
        self.d_model = configs.d_model
        self.seq_len = configs.seq_len

        # =========================
        # Branch：原始序列 → 系数
        # 保持你第一个代码中的结构
        # =========================
        self.branch_net = nn.Sequential(
            nn.LayerNorm(self.seq_len),
            nn.Linear(self.seq_len, 256),
            nn.GELU(),
            nn.Linear(256, self.num_basis),
            nn.Dropout(0.1)
        )

        # =========================
        # Trunk：文本 → 隐表示
        # 保持你第一个代码中的结构
        # =========================
        self.text_mlp = nn.Sequential(
            nn.LayerNorm(self.d_model),
            nn.Linear(self.d_model, 256),
            nn.GELU(),
            nn.Dropout(0.1)
        )

        # =========================
        # 文本控制的基函数参数
        # =========================
        self.to_w = nn.Linear(256, self.num_basis)
        self.to_alpha = nn.Linear(256, self.num_basis)
        self.to_omega = nn.Linear(256, self.num_basis)
        self.to_phi = nn.Linear(256, self.num_basis)

        # =========================
        # 动态门控机制
        # =========================
        self.to_gate = nn.Linear(256, self.num_basis)

        self.bias = nn.Parameter(torch.zeros(1))

    def forward(self, branch_input, text_feat, shift=None):
        """
        branch_input:
            [B, 1, F]

        text_feat:
            支持两种形式：
            1. [B, 1, D]：单条文本事件
            2. [B, L, D]：多条文本事件并行计算

        shift:
            可选。
            如果 text_feat 是 [B, L, D]，shift 可以是 [L]，
            用于给不同事件加入不同时间偏移。

        return:
            [B, pred_len]
        """

        # =========================
        # 1. Branch
        # =========================
        branch_input = branch_input.squeeze(1)          # [B, F]
        branch_out = self.branch_net(branch_input)      # [B, K]

        B = branch_input.size(0)
        K = self.num_basis

        # =========================
        # 2. 兼容单事件输入 [B, 1, D]
        # =========================
        if text_feat.dim() == 2:
            text_feat = text_feat.unsqueeze(1)          # [B, 1, D]

        B, L, D = text_feat.shape

        # =========================
        # 3. Text MLP
        # =========================
        text_feat_flat = text_feat.reshape(B * L, D)    # [B*L, D]
        text_embed = self.text_mlp(text_feat_flat)      # [B*L, 256]

        # =========================
        # 4. 文本生成基函数参数
        # =========================
        w = self.to_w(text_embed)                       # [B*L, K]
        alpha = F.softplus(self.to_alpha(text_embed))   # [B*L, K]
        omega = F.softplus(self.to_omega(text_embed))   # [B*L, K]
        phi = self.to_phi(text_embed)                   # [B*L, K]

        # =========================
        # 5. 动态门控机制：STE
        # =========================
        gate_logits = self.to_gate(text_embed)          # [B*L, K]
        gate_prob = torch.sigmoid(gate_logits)          # [B*L, K]

        threshold = gate_prob.mean(dim=-1, keepdim=True)
        gate_hard = (gate_prob > threshold).float()

        # Straight-Through Estimator
        gate = gate_hard - gate_prob.detach() + gate_prob  # [B*L, K]

        # =========================
        # 6. 恢复事件维度
        # =========================
        w = w.view(B, L, K)              # [B, L, K]
        alpha = alpha.view(B, L, K)
        omega = omega.view(B, L, K)
        phi = phi.view(B, L, K)
        gate = gate.view(B, L, K)

        # =========================
        # 7. 时间 t
        # =========================
        t = torch.linspace(
            0,
            2 * torch.pi,
            self.pred_len,
            device=branch_input.device,
            dtype=branch_input.dtype
        )  # [T]

        if shift is None:
            shift = torch.zeros(
                L,
                device=branch_input.device,
                dtype=branch_input.dtype
            )

        if isinstance(shift, int):
            shift = torch.tensor(
                [shift],
                device=branch_input.device,
                dtype=branch_input.dtype
            )

        shift = shift.to(
            device=branch_input.device,
            dtype=branch_input.dtype
        )  # [L]

        # t_shifted: [L, T]
        t_shifted = t.unsqueeze(0) + shift.unsqueeze(1)

        # [1, L, T, 1]
        t_shifted = t_shifted.unsqueeze(0).unsqueeze(-1)

        # =========================
        # 8. reshape
        # =========================
        branch_out = branch_out.unsqueeze(1).unsqueeze(2)  # [B, 1, 1, K]

        w = w.unsqueeze(2)          # [B, L, 1, K]
        alpha = alpha.unsqueeze(2)
        omega = omega.unsqueeze(2)
        phi = phi.unsqueeze(2)
        gate = gate.unsqueeze(2)

        # =========================
        # 9. 基函数
        #sin、cos、exp...
        # basis = sin + cos.....             # [B, L, T, K]


        # =========================
        # 10. Branch-Trunk 组合
        # =========================
        tau = branch_out * basis * w * gate                  # [B, L, T, K]

        # 对 basis 维度 K 求和，再对事件维度 L 求和
        y = tau.sum(dim=-1).sum(dim=1) + self.bias           # [B, T]

        return y



