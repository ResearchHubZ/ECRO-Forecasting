import torch
import torch.nn as nn
# from model import iTransformer
from layers.Embed import PositionalEmbedding
from layers.SelfAttention_Family import FullAttention, AttentionLayer
from layers.modality_connector import ModalityConnector, TextEncoder
import math
from layers.prototype_retriever import PrototypeRetriever
from layers.flow_loss import FlowLoss
from einops import rearrange
from transformers.modeling_outputs import MoeCausalLMOutputWithPast
from layers.Decoder_layer import Attention, FFN
import torch.nn.functional as F
from layers.filter import TexFilter
from layers.Embed import DataEmbedding_inverted
from model import iTransformer, PatchTST, Crossformer, DLinear, TimeXer, WPMixer, DeformTime, Informer, Transformer
from model.Operator import TextTrunk

class EnEmbedding(nn.Module):
    def __init__(self, n_vars, d_model, patch_len, dropout):
        super(EnEmbedding, self).__init__()
        # Patching
        self.patch_len = patch_len
        self.value_embedding = nn.Linear(patch_len, d_model, bias=False)
        self.glb_token = nn.Parameter(torch.randn(1, n_vars, 1, d_model))
        self.position_embedding = PositionalEmbedding(d_model)

        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # do patching
        n_vars = x.shape[1]
        glb = self.glb_token.repeat((x.shape[0], 1, 1, 1))
        x = x.unfold(dimension=-1, size=self.patch_len, step=self.patch_len)
        x = torch.reshape(x, (x.shape[0] * x.shape[1], x.shape[2], x.shape[3]))
        # Input encoding
        x = self.value_embedding(x) + self.position_embedding(x)
        x = torch.reshape(x, (-1, n_vars, x.shape[-2], x.shape[-1]))
        x = torch.cat([x, glb], dim=2)
        x = torch.reshape(x, (x.shape[0] * x.shape[1], x.shape[2], x.shape[3]))
        return self.dropout(x), n_vars

def causal_attention_mask(seq_length):
    mask = torch.triu(torch.ones(seq_length, seq_length) * float('-inf'), diagonal=1)
    return mask.unsqueeze(0).unsqueeze(0)
class Transpose(nn.Module):
    def __init__(self, *dims, contiguous=False):
        super().__init__()
        self.dims, self.contiguous = dims, contiguous

    def forward(self, x):
        if self.contiguous:
            return x.transpose(*self.dims).contiguous()
        else:
            return x.transpose(*self.dims)
        
class DecoderLayer(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.self_attn = Attention(config, rope=False)
        self.cross_attn = Attention(config, rope=True)

        self.ffn_layer = FFN(
            hidden_size=config.d_model,
            intermediate_size=config.intermediate_size,
            hidden_act=config.hidden_act
        )
        if config.norm_mode == 'batch':
            self.norm1 = nn.Sequential(Transpose(1, 2), nn.BatchNorm1d(config.d_model), Transpose(1, 2))
            self.norm2 = nn.Sequential(Transpose(1, 2), nn.BatchNorm1d(config.d_model), Transpose(1, 2))
            self.norm3 = nn.Sequential(Transpose(1, 2), nn.BatchNorm1d(config.d_model), Transpose(1, 2))
        else:
            self.norm1 = torch.nn.LayerNorm(config.d_model)
            self.norm2 = torch.nn.LayerNorm(config.d_model)
            self.norm3 = torch.nn.LayerNorm(config.d_model)

    def forward(self, hidden_states, cross_states):
        residual = hidden_states

        num_token = hidden_states.shape[1]
        attention_mask = causal_attention_mask(num_token).to('cuda')

        # Self Attention
        hidden_states, self_attn_weights = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            output_attentions=None,
        )
        x_attn = residual + self.norm1(hidden_states)

        x_cross, cross_attn_weights = self.cross_attn(hidden_states=x_attn, key_embedding=cross_states,
                                                      value_embedding=cross_states)
        x_cross = self.norm2(x_cross) + x_attn

        # Fully Connected
        output_states = self.ffn_layer(x_cross)
        output_states = self.norm3(output_states) + x_cross

        return output_states
def resize(x_tensor, new_shape):
    return F.interpolate(x_tensor.unsqueeze(0), size=new_shape, mode='linear').squeeze(0)
def resample(old: torch.Tensor, new_patch_len: int):
    assert old.dim() == 2, "the size of input tensor should be (d_model, patch_size)"
    if old.size(1) == new_patch_len:
        return old

    old = old.T
    old_shape = old.size(0)
    factor = new_patch_len / old_shape

    basis_vectors = torch.eye(old_shape, dtype=torch.get_default_dtype(), device=old.device)
    resize_mat = resize(basis_vectors, new_patch_len).T
    resize_mat_pinv = torch.linalg.pinv(resize_mat.T)

    resampled_kernels = resize_mat_pinv @ old * math.sqrt(factor)

    return resampled_kernels.T  
 
class PredictHead(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.output_proj = nn.Linear(config.d_model, config.token_len, bias=False)
        self.dropout = nn.Dropout(config.dropout)

    def _predict(self, hidden_states: torch.Tensor, inference_token_len=48):
        resampled_weight = resample(old=self.output_proj.weight.data.T, new_patch_len=inference_token_len).T
        output = F.linear(hidden_states, resampled_weight)
        return output

    def forward(
            self,
            hidden_states: torch.Tensor,
            inference_token_len: int = 48,
            **kwargs
    ):
        if not self.training:
            return self._predict(hidden_states, inference_token_len)

        return self.output_proj(self.dropout(hidden_states))
      
class Model(nn.Module):
    def __init__(self, configs):
        super(Model, self).__init__()
        self.configs = configs
        self.TextEncoder = TextEncoder(configs)
        self.device = 'cuda'

        self.point_loss = torch.nn.MSELoss(reduction='none')

        model_dict = {
            'DLinear': DLinear,
            'iTransformer': iTransformer,
            'PatchTST': PatchTST,
            'Crossformer': Crossformer,
            'TimeXer': TimeXer,
            'WPMixer': WPMixer,
            'DeformTime': DeformTime,
            'Informer': Informer,
            'Transformer': Transformer
        }

        main_model = model_dict[configs.main_model]
        self.small_model = main_model.Model(configs).float()

        # 算子网络 / 残差响应网络
        self.operator = TextTrunk(configs).float()

    def _filtered_mean_loss(self, loss_tensor, eps=1e2):
        """
        对逐点 loss 做异常值过滤。
        若过滤后仍有元素，则返回过滤后的均值；
        否则返回原始均值，避免空张量导致 NaN。
        """
        loss_filter = loss_tensor[loss_tensor < eps]
        if loss_filter.numel() > 0:
            return loss_filter.mean()
        else:
            return loss_tensor.mean()

    def forward(
        self,
        x_enc,
        x_mark_enc,
        x_dec,
        x_mark_dec,
        text_input_ids,
        text_attention_mask,
        text_token_type_ids,
        labels,
        return_explain=False
    ):

        # ======================================================
        # 1. 基础预测器输出
        # ======================================================
        pred, _, init_data = self.small_model(
            x_enc[:, :, :],
            x_mark_enc,
            x_dec,
            x_mark_dec,
            mask=None
        )

        pred = pred.permute(0, 2, 1)             # [B, 1, pred_len]
        init_data = init_data.permute(0, 2, 1)   # [B, 1, F]

        # ======================================================
        # 2. 文本编码
        # text_features 表示整个历史窗口内的文本/事件特征
        # ======================================================
        if text_input_ids is not None:
            text_features = self.TextEncoder({
                'input_ids': text_input_ids,
                'attention_mask': text_attention_mask,
                'token_type_ids': text_token_type_ids
            })
        else:
            text_features = None

        # ======================================================
        # 3. 计算整个历史窗口的总残差响应
        # 这里不是单事件残差，而是所有历史窗口事件聚合后的总残差
        # residual: [B, pred_len]
        # ======================================================
        if text_features is not None:
            shifts = torch.arange(
                self.configs.seq_len,
                device=init_data.device,
                dtype=init_data.dtype
            )

            residual = self.operator(
                init_data,
                text_features,
                shift=shifts
            )   # [B, pred_len]
        else:
            residual = torch.zeros(
                pred.shape[0],
                self.configs.pred_len,
                device=pred.device,
                dtype=pred.dtype
            )

        # ======================================================
        # 4. 最终预测 = 基础预测 + 总残差
        # ======================================================
        base_pred = pred.squeeze(1)                       # [B, pred_len]
        final_pred = base_pred + residual                 # [B, pred_len]
        final_predictions = final_pred.unsqueeze(2)        # [B, pred_len, 1]

        # ======================================================
        # 5. Loss
        # 总 loss = 最终预测 loss + 基础预测器 loss + 残差响应 loss
        # ======================================================
        loss = None
        loss_final = None
        loss_base = None
        loss_residual = None

        eps = 1e2

        if labels is not None:
            labels = labels[:, :, -1]  # [B, pred_len]

            # --------------------------------------------------
            # 5.1 最终预测 loss
            # final_pred = base_pred + residual
            # --------------------------------------------------
            final_loss_point = self.point_loss(
                final_pred,
                labels
            )  # [B, pred_len]

            loss_final = self._filtered_mean_loss(
                final_loss_point,
                eps=eps
            )

            # --------------------------------------------------
            # 5.2 基础预测器 loss
            # base_pred 直接拟合真实标签
            # --------------------------------------------------
            base_loss_point = self.point_loss(
                base_pred,
                labels
            )  # [B, pred_len]

            loss_base = self._filtered_mean_loss(
                base_loss_point,
                eps=eps
            )

            # --------------------------------------------------
            # 5.3 残差响应 loss
            # residual 应拟合真实残差：
            # residual_target = labels - base_pred
            #
            # 这里使用 base_pred.detach()，避免 residual loss
            # 反向干扰基础预测器，只训练残差响应网络。
            # --------------------------------------------------
            residual_target = labels - base_pred.detach()  # [B, pred_len]

            residual_loss_point = self.point_loss(
                residual,
                residual_target
            )  # [B, pred_len]

            loss_residual = self._filtered_mean_loss(
                residual_loss_point,
                eps=eps
            )

            # --------------------------------------------------
            # 5.4 三个 loss 的总和
            # --------------------------------------------------
            loss = loss_final + loss_base + loss_residual

        # ======================================================
        # 6. 解释模式：返回基础预测、总残差、最终预测和各项 loss
        # ======================================================
        if return_explain:
            return {
                "loss": loss,
                "loss_final": loss_final,
                "loss_base": loss_base,
                "loss_residual": loss_residual,
                "logits": final_predictions,      # [B, pred_len, 1]
                "base_pred": pred.detach(),       # [B, 1, pred_len]
                "residual": residual.detach(),    # [B, pred_len]
            }

        return MoeCausalLMOutputWithPast(
            loss=loss,
            logits=final_predictions,
        )